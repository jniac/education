import THREE from '../THREE.js'
import { scene, getTexture, setAutoPauseDelay } from '../setup.js'
import { makeRing } from '../makeRing.js'
import { rad } from '../utils/utils.js'

// un conteneur
const container = new THREE.Object3D()
scene.add(container)

for (const obj of makeRing({
    count: 6,
    radius: 1.2,
    parent: container,
    // debug: true,
})) {
    
    const geometry = new THREE.PlaneGeometry(2, 2)

    const material = new THREE.MeshBasicMaterial({
        color: '#C3D5FF',
        side: THREE.DoubleSide,
        alphaMap: getTexture('./assets/leaf-1.png'),
        transparent: true,
        depthWrite: false,
        // wireframe: true,
    })

    const plane = new THREE.Mesh( geometry, material )
    plane.rotation.x = rad(30)
    obj.add(plane)
}

container.update = () => {
    container.rotation.y += rad(0.1)
}

setAutoPauseDelay(100)

