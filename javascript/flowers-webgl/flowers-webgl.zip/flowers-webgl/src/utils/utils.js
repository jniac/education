
export const deg = x => x * 180 / Math.PI
export const rad = x => x * Math.PI / 180
