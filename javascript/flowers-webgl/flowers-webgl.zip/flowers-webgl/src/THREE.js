import * as THREE from 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r123/three.module.js'

Object.assign(window, { THREE })

export default THREE