
export const RED = '#d6001d'
export const BLUE = '#2340d3'
export const YELLOW = '#ffeb3b'
