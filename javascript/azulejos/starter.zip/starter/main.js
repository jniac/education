
let rotateTile = (element) => {

	// alt + shift + L > |
	// altGr + ?? > |
	let a = (element.a || 0) + 90
	element.a = a
	element.style.transform = 'rotate(' + a + 'deg)'

}

let rotateRandomTile = () => {

	let tiles = document.querySelectorAll('section#s2 div.tile')
	let index = Math.floor(Math.random() * tiles.length)
	let randomTile = tiles[index]
	rotateTile(randomTile)

}

setInterval(rotateRandomTile, 3000)






let makeGrid = (col, row, tileSize) => {

	let container = document.querySelector('section#s3 div.grid')
	alert(container)

}

makeGrid(8, 6, 120)
