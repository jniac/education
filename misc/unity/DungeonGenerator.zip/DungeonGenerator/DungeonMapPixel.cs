﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DungeonMapPixel : MonoBehaviour
{
    public Color32 pixelColor;
    public GameObject prefab;
    public bool isWall;
}
