
export default {

    width: 300,
    height: 300,
    canvasScaleRatio: 3,

}
