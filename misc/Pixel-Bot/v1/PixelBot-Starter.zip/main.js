class ColorMixer extends PixelBot {

    start() {

        this.x = 200
        this.y = 200

    }

    update() {

        if (Math.random() < .005) {

            this.turn(Math.random() < .5)

        }

        let color = new Color(
            this.pixelColor.b * .9,
            this.pixelColor.r * .9,
            this.pixelColor.g * .9,
        )

        this.setPixelColor(color)

        this.move()

    }

}

class LangtonAnt extends PixelBot {

    start() {

        this.x = 150
        this.y = 150
        this.color1 = '#fc0'
        this.color2 = '#0cf'

    }

    update() {

        if (this.pixelColor.r < .5) {

            this.turnLeft()
            this.setPixelColor(this.color1)

        } else {

            this.turnRight()
            this.setPixelColor(this.color2)

        }

        this.move()

    }

}

new LangtonAnt()
new LangtonAnt().set({
    x: 100,
    y: 200,
    color1: '#f0c',
    color2: '#0fc',
})
new ColorMixer()
